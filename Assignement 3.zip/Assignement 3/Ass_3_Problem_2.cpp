#include <iostream>
using namespace std;

int main() {
    char choice;

    while (true) {
        cout << "Welcome to Birthday Date Meaning Generator!" << endl;
        cout << "Please enter the month of your birthday: ";
        int month;
        cin >> month;

        if (month < 1 || month > 12) {
            cout << "Invalid month. Please enter a valid month (1-12)." << endl;
            continue;
        }

        cout << "Please enter the day of your birthday: ";
        int day;
        cin >> day;

        if (day < 1 || day > 31) {
            cout << "Invalid day. Please enter a valid day (1-31)." << endl;
            continue;
        }

        cout << "Please enter the year of your birthday (2000-2023): ";
        int year;
        cin >> year;

        if (year < 2000 || year > 2023) {
            cout << "Invalid year. Please enter a year between 2000 and 2023." << endl;
            continue;
        }

        cout << "The month of ";
        switch (month) {
            case 1:
                cout << "January";
                break;
            case 2:
                cout << "February";
                break;
            case 3:
                cout << "March";
                break;
            case 4:
                cout << "April";
                break;
            case 5:
                cout << "May";
                break;
            case 6:
                cout << "June";
                break;
            case 7:
                cout << "July";
                break;
            case 8:
                cout << "August";
                break;
            case 9:
                cout << "September";
                break;
            case 10:
                cout << "October";
                break;
            case 11:
                cout << "November";
                break;
            case 12:
                cout << "December";
                break;
            // Add cases for other months here
            default:
                cout << "Invalid month";
                break;
        }
        cout << " means ";

        switch (month) {
            case 1:
                cout << "Janus";
                break;
            case 2:
                cout << "Februum";
                break;
			case 3:
                cout << "Mars";
                break;
            case 4:
                cout << "Aprillis";
                break;
            case 5:
                cout << "Maius";
                break;
            case 6:
                cout << "Juno";
                break;
            case 7:
                cout << "fifth month";
                break;
            case 8:
                cout << "Augustus";
                break;
            case 9:
                cout << "Seven";
                break;
            case 10:
                cout << "Octo";
                break;
            case 11:
                cout << "Nine";
                break;
            case 12:
                cout << "ten";
                break;
            // Add meanings for other months here
            default:
                cout << "Invalid month";
                break;
        }

        cout << endl;

        cout << "The " << day << " of ";
        switch (month) {
            case 1:
                cout << "January";
                break;
            case 2:
                cout << "February";
                break;
             case 3:
                cout << "March";
                break;
            case 4:
                cout << "April";
                break;
            case 5:
                cout << "May";
                break;
            case 6:
                cout << "June";
                break;
            case 7:
                cout << "July";
                break;
            case 8:
                cout << "August";
                break;
            case 9:
                cout << "September";
                break;
            case 10:
                cout << "October";
                break;
            case 11:
                cout << "November";
                break;
            case 12:
                cout << "December";
                break;
			// Add cases for other months here
            default:
                cout << "Invalid month";
                break;
        }
        cout << " means ";

        switch (day) {
            case 1:
                cout << "Self-Started";
                break;
            case 2:
                cout << "you have a great talent for finding solutions";
                break;
            case 3:
                cout << "You are very skilled at communicating your thoughts";
                break;
            case 4:
                cout << "You bring stability";
                break;
            case 5:
                cout << "You are flexibile";
                break;
            case 6:
                cout << "Your heart is your gift";
                break;
            case 7:
                cout << "You possess a very refined mind";
                break;
            case 8:
                cout << "You are a story of success";
                break;
            case 9:
                cout << "You are devoted to helping others";
                break;
            case 10:
                cout << "You have a great leadership skills";
                break;
            case 11:
                cout << "You have a keen awareness of what's happening around you";
                break;
            case 12:
                cout << "You are very creative";
                break;
            case 13:
                cout << "You are conscientious worker with a knack for comming up with creative ideas";
                break;
            case 14:
                cout << "You are open minded";
                break;
            case 15:
                cout << "You are love for others";
                break;
            case 16:
                cout << "You have special ability to read into other people's feeling'";
                break;
            case 17:
                cout << "You are as independent as you are ambitious";
                break;
            case 18:
                cout << "You are open minded and open hearted";
                break;
            case 19:
                cout << "You are independent and self-sufficient";
                break;
            case 20:
                cout << "You relate to others on an almost cosmic level";
                break;
            case 21:
                cout << "You thrive in active social settings";
                break;
            case 22:
                cout << "You have power to create great things";
                break;
            case 23:
                cout << "You are real zest for life and you're eager tpo experience anything and everything possible'";
                break;
            case 24:
                cout << "You have a heart of gold";
                break;
            case 25:
                cout << "You have ability to take in and process information on both conscious and subconscious level";
                break;
            case 26:
                cout << "You have a desire to succeed";
                break;
            case 27:
                cout << "Your mind in wide open and you tolerate";
                break;
            case 28:
                cout << "You have leadership skills";
                break;
            case 29:
                cout << "You have amazing ability to bring things together";
                break;
            case 30:
                cout << "You are an orignal, innovative thinker and an excellent communicator";
                break;
            case 31:
                cout << "Your approach to life is an effective mix of both practicality and imagination";
                break;
            // Add meanings for other days here
            default:
                cout << "Invalid day";
                break;
        }

        cout << endl;

        cout << "The year of " << year << " means ";
        if (year >= 2000 && year <= 2023) {
        	switch (year) {
            case (2000):
                cout << "that you are millennial";
                break;
            case (2001):
                cout << "You have a lot of enery";
                break;
            case (2002):
                cout << "You don't like to be restrained by convention, wishing instead to go your own way";
                break;
            case (2003):
                cout << "You have a tendency to worry, and need to learn to control this tendency";
                break;
            case (2004):
                cout << "You have strong willed, intelligent and creative";
                break;
            case (2005):
                cout << "You are honnest, intelligent and ambitious and like to rely on yourself rather than other";
                break;
            case (2006):
                cout << "You are straightforward in thought and speech";
                break;
            case (2007):
                cout << "People find you honest";
                break;
            case (2008):
                cout << "You are easygoing and adaptable adn fit into just about any situation";
                break;
            case (2009):
                cout << "You are silent and hardworking";
                break;
            case (2010):
                cout << "You have tendency to resist authority and want to do your own things";
                break;
            case (2011):
                cout << "You are sensitive and can take things to personally";
                break;
            case (2012):
                cout << "You are impatient and want everything quickly";
                break;
            case (2013):
                cout << "You have a lot of energy and have difficulty controlling it";
                break;
            case (2014):
                cout << "You desire a high profile career adn love to be surrounded by loving admirers";
                break;
            case (2015):
                cout << "You have strong faith which will help you through out your life";
                break;
            case (2016):
                cout << "You have spent your life carring for others, and they find you gentle, warm and trustworthy";
                break;
            case (2017):
                cout << "You show who you really are and people take comfort in your strength of character";
                break;
            case (2018):
                cout << "You are very fond of both science and art";
                break;
            case (2019):
                cout << "You are dominating and assertive";
                break;
            case (2020):
                cout << "You have a desire for balance and harmony";
                break;
            default:
                cout << "Invalid day";
                break;
        }
}
        cout << endl;

        cout << "Would you like to try another one? (Type 'N' to exit): ";
        cin >> choice;
        if (choice == 'N' || choice == 'n') {
            cout << "Thanks for playing!" << endl;
            break;
        }
    }
return 0;
}
