# BMI Calculator

## Overview

Welcome to the BMI Calculator program! This C++ console application prompts users to input their personal information, such as name, age, gender, height, and weight. It then calculates the Body Mass Index (BMI) based on the provided data and determines the BMI status according to the BMI chart.

## How to Use

1. **Clone the Repository:**

2. **Compile and Run:**

   - Compile the C++ code using a C++ compiler (e.g., g++).

   - Run the compiled executable.

3. **Provide Your Information:**

   - Respond to the prompts by entering your name, age, gender, height in feet, height in inches, and weight in pounds.

4. **View Results:**

   - The application will calculate your BMI, determine your BMI status, and display the results.

## BMI Chart

The BMI status is determined based on the following chart:

- BMI < 16: Severe Thinness
- 16 <= BMI < 17: Moderate Thinness
- 17 <= BMI < 18.5: Mild Thinness
- 18.5 <= BMI < 25: Normal
- 25 <= BMI < 30: Obese Class 1
- 30 <= BMI < 35: Obese Class 2
- BMI >= 35: Obese Class 3

## OUTPUT:

![71bd6216-8927-4f88-b3f9-ce8eb1f723e6](C:\Users\pc\Downloads\71bd6216-8927-4f88-b3f9-ce8eb1f723e6.jpeg)