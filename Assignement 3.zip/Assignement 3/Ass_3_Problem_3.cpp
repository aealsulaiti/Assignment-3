#include <iostream>
#include <cmath>
#include <string>

int main() {
    std::string operation;
    double num1, num2, result;

    // Ask the user to enter a problem
    std::cout << "Enter a problem to solve (e.g., 5 + 3, sin 30): ";
    std::cin >> operation;

    // Check if the operation is a unary function
    if (operation == "sin" || operation == "asin" || operation == "cos" || operation == "acos" ||
        operation == "tan" || operation == "atan" || operation == "sqrt" || operation == "ceil" ||
        operation == "abs" || operation == "floor" || operation == "round" || operation == "log" ||
        operation == "log10" || operation == "log2") {

        // Handle unary functions
        std::cin >> num1;
        if (operation == "sin") {
            result = sin(num1);
        } else if (operation == "asin") {
            result = asin(num1);
        } else if (operation == "cos") {
            result = cos(num1);
        } else if (operation == "acos") {
            result = acos(num1);
        } else if (operation == "tan") {
            result = tan(num1);
        } else if (operation == "atan") {
            result = atan(num1);
        } else if (operation == "sqrt") {
            result = sqrt(num1);
        } else if (operation == "ceil") {
            result = ceil(num1);
        } else if (operation == "abs") {
            result = abs(num1);
        } else if (operation == "floor") {
            result = floor(num1);
        } else if (operation == "round") {
            result = round(num1);
        } else if (operation == "log") {
            result = log(num1);
        } else if (operation == "log10") {
            result = log10(num1);
        } else if (operation == "log2") {
            result = log2(num1);
        } else {
            std::cout << "Invalid unary function\n";
            return 1; // Exit with an error code
        }

    } else {
        // Handle binary operators
        std::cin >> num1 >> operation >> num2;
        if (operation == "+") {
            result = num1 + num2;
        } else if (operation == "-") {
            result = num1 - num2;
        } else if (operation == "*") {
            result = num1 * num2;
        } else if (operation == "/") {
            if (num2 != 0) {
                result = num1 / num2;
            } else {
                std::cout << "Error: Division by zero\n";
                return 1; // Exit with an error code
            }
        } else if (operation == "%") {
            if (num2 != 0) {
                result = fmod(num1, num2);
            } else {
                std::cout << "Error: Modulus by zero\n";
                return 1; // Exit with an error code
            }
        } else if (operation == "^") {
            result = pow(num1, num2);
        } else if (operation == "max") {
            result = std::max(num1, num2);
        } else if (operation == "min") {
            result = std::min(num1, num2);
        } else {
            std::cout << "Invalid binary operator\n";
            return 1; // Exit with an error code
        }
    }

    // Output the result
    std::cout << "Result: " << result << std::endl;

    return 0;
}
