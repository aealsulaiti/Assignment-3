#  Basic Math Calculator

## Overview

Welcome to the Basic Math Calculator! This C++ console application allows you to solve various mathematical problems by entering expressions or unary functions. The program supports basic arithmetic operations, trigonometric functions, logarithmic functions, and more.

## How to Use

1. **Clone the Repository:**

2. **Compile and Run:**

   - Compile the C++ code using a C++ compiler (e.g., g++).

   - Run the compiled executable.

3. **Enter a Problem:**

   - Enter a mathematical problem or unary function when prompted (e.g., `5 + 3`, `sin 30`, `log 100`).

4. **View Results:**

   - The application will evaluate the expression or function and display the result.

5. **Unary Functions:**

   - You can use unary functions like `sin`, `asin`, `cos`, `acos`, `tan`, `atan`, `sqrt`, `ceil`, `abs`, `floor`, `round`, `log`, `log10`, and `log2`.

6. **Binary Operators:**

   - Supported binary operators are `+` (addition), `-` (subtraction), `*` (multiplication), `/` (division), `%` (modulus), `^` (exponent), `max`, and `min`.

7. **Error Handling:**

   - The program handles errors such as division by zero or modulus by zero and provides appropriate error messages.

8. **Exit the Program:**

   - To exit the program, simply enter `N` when prompted to try another problem.

## Examples

- For addition: `5 + 3`
- For trigonometric functions: `sin 30`, `acos 0.5`
- For logarithmic functions: `log 100`, `log10 1000`
- For binary operators: `10 * 2`, `3^4`, `max 8 5`

Feel free to experiment with different mathematical problems using this Basic Math Calculator. If you encounter any issues or want to contribute, your feedback is welcome!

## OUTPUT:

![8a6e36e2-b9cc-4164-903e-342473c510de](C:\Users\pc\Downloads\8a6e36e2-b9cc-4164-903e-342473c510de.jpeg)![5d464794-d4b6-4640-b495-683b5d937750](C:\Users\pc\Downloads\5d464794-d4b6-4640-b495-683b5d937750.jpeg)