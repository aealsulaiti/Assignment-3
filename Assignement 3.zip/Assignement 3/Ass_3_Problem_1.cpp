#include <iostream>
#include <iomanip>
#include <string>

int main() {
    // Variables to store user information
    std::string name, gender;
    int age, heightFeet, weightPounds;
    double heightInches, heightInchesTotal, bmi;

    // Ask the user to enter their information
    std::cout << "Please enter your name: ";
    std::getline(std::cin, name);

    std::cout << "Please enter your age: ";
    std::cin >> age;

    std::cout << "Please enter your gender (male/female): ";
    std::cin >> gender;

    std::cout << "Please enter your height in feet: ";
    std::cin >> heightFeet;

    std::cout << "Please enter your height in inches (including decimal values): ";
    std::cin >> heightInches;

    std::cout << "Please enter your weight in pounds: ";
    std::cin >> weightPounds;

    // Convert height to inches
    heightInchesTotal = (heightFeet * 12) + heightInches;

    // Calculate BMI
    bmi = (703.0 * weightPounds) / (heightInchesTotal * heightInchesTotal);

    // Determine BMI status
    std::string bmiStatus;
    if (bmi < 16) {
        bmiStatus = "Severe Thinness";
    } else if (bmi < 17) {
        bmiStatus = "Moderate Thinness";
    } else if (bmi < 18.5) {
        bmiStatus = "Mild Thinness";
    } else if (bmi < 25) {
        bmiStatus = "Normal";
    } else if (bmi < 30) {
        bmiStatus = "Obese Class 1";
    } else if (bmi < 35) {
        bmiStatus = "Obese Class 2";
    } else {
        bmiStatus = "Obese Class 3";
    }

    // Output the result
    std::cout << std::fixed << std::setprecision(2); // Set precision for the BMI value
    std::cout << "\nHi " << name << ",\n";
    std::cout << "You are a " << gender << ". You are " << age << " years old. ";
    std::cout << "You are currently " << heightFeet << "' " << heightInches << "\" and ";
    std::cout << "you currently weigh " << weightPounds << " pounds. ";
    std::cout << "Your BMI is " << bmi << ", which is " << bmiStatus << ".\n";
    std::cout << "Thank you for using the BMI Calculator!\n";

    return 0;
}
